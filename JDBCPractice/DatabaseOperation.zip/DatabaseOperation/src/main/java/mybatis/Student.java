package mybatis;

import java.text.SimpleDateFormat;

public class Student {
    private int id;
    private String name;
    private String number;
    private Long create_at;
    private Long update_at;
    public Student(){}//无参构造方法
    public Student(int id, String name, String number,Long update_at){//更新信息时要用的构造方法
        this.id=id;
        this.name=name;
        this.number=number;
        this.update_at=update_at;
    }
    public Student(int id, String name, String number,Long create_at,Long update_at){//新增学生信息时用的构造方法
        this.id=id;
        this.name=name;
        this.number=number;
        this.create_at=create_at;
        this.update_at=update_at;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Long getCreate_at() {
        return create_at;
    }

    public void setCreate_at(Long create_at) {
        this.create_at = create_at;
    }

    public Long getUpdate_at() {
        return update_at;
    }

    public void setUpdate_at(Long update_at) {
        this.update_at = update_at;
    }

    public String toString() {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return "学生:id=" + id + ", name=" + name + ", number="
                + number +", create_at:"+df.format(create_at)+", update_at:"+df.format(update_at);
    }
}
