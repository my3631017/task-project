package mybatis;

import org.apache.ibatis.session.SqlSession;

import java.util.Iterator;
import java.util.List;

public class StuDaoImpl implements dao.StuDao {
    SqlSession sqlSession;
    public StuDaoImpl(SqlSession sqlSession) {
        this.sqlSession = sqlSession;
    }
    public Student selectById(int id) {
        Student student=sqlSession.selectOne("test.findStudentById",id);
        System.out.println(student);
        sqlSession.close();
        return null;
    }

    public Student selectByName(String name) {
        Student student=sqlSession.selectOne("test.findByName",name);
        System.out.println(student);
        sqlSession.close();
        return null;
    }

    public List<Student> selectAll() {
        List<Student> students=sqlSession.selectList("test.findAllStudent");
        Iterator stu=students.iterator();
        while (stu.hasNext()){
            System.out.println(stu.next());
        }
        sqlSession.close();
        return null;
    }

    public void insert(Student student) {
        sqlSession.insert("test.insertStudent",student);
        sqlSession.commit();
        sqlSession.close();
    }

    public void delete(int id) {
        sqlSession.delete("test.deleteStudent", id);
        sqlSession.commit();
        sqlSession.close();
    }

    public void update(Student student) {
        sqlSession.update("test.updateStudent", student);
        sqlSession.commit();
        sqlSession.close();
    }
}