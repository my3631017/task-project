package jdbc;

public class Operation {
    public static void main(String[] args) {
        Demo s=new Demo();
//        s.insert(5,"刘君健","26346423");
//        s.delete(3);
//        s.update(4,"乱世枭雄","233333");
//        s.select(4);
        s.select();
    }
}
