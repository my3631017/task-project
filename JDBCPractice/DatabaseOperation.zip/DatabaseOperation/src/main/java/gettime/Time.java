package gettime;

import java.util.Date;

public class Time {
    public Long time=System.currentTimeMillis();
//    public Long time;
//    public Time(){
//        Date date=new Date();
//        this.time=date.getTime();
//    }
}
