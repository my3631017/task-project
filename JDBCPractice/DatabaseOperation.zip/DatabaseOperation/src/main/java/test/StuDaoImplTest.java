package test;

import dao.StuDao;
import getsqlsession.GetSqlSession;
import mybatis.StuDaoImpl;
import mybatis.Student;
import org.apache.ibatis.session.SqlSession;

public class StuDaoImplTest {
    public void testFindStudentById() throws Exception {
        getsqlsession.GetSqlSession getSqlSession=new GetSqlSession();
        SqlSession sqlSession=getSqlSession.getSession();
        //创建StuDao的对象
        StuDao stuDao = new StuDaoImpl(sqlSession);
        System.out.println(stuDao.selectById(2));
    }
    public void testFindStudentByName()throws Exception{
        getsqlsession.GetSqlSession getSqlSession=new GetSqlSession();
        SqlSession sqlSession=getSqlSession.getSession();
        StuDao stuDao = new StuDaoImpl(sqlSession);
        System.out.println(stuDao.selectByName("万全林"));
    }
    public void testFindStudents()throws Exception{
        getsqlsession.GetSqlSession getSqlSession=new GetSqlSession();
        SqlSession sqlSession=getSqlSession.getSession();
        StuDao stuDao = new StuDaoImpl(sqlSession);
        System.out.println(stuDao.selectAll());
    }
    public void testInsertStudent()throws Exception{
        getsqlsession.GetSqlSession getSqlSession=new GetSqlSession();
        SqlSession sqlSession=getSqlSession.getSession();
        StuDao stuDao = new StuDaoImpl(sqlSession);
        Long time=System.currentTimeMillis();
        Student stu=new Student(6,"王建伟","1111438",time,time);
        stuDao.insert(stu);
    }
    public void testDeleteStudent()throws Exception{
        getsqlsession.GetSqlSession getSqlSession=new GetSqlSession();
        SqlSession sqlSession=getSqlSession.getSession();
        StuDao stuDao = new StuDaoImpl(sqlSession);
        stuDao.delete(6);
    }
    public void testUpdateStudent()throws Exception{
        getsqlsession.GetSqlSession getSqlSession=new GetSqlSession();
        SqlSession sqlSession=getSqlSession.getSession();
        StuDao stuDao = new StuDaoImpl(sqlSession);
        Long time=System.currentTimeMillis();
        Student stu=new Student(5,"宋晓胜","16438",time);
        stuDao.update(stu);
    }
    public static void main(String[] args) {
        StuDaoImplTest stuDaoImplTest=new StuDaoImplTest();
        try {
//            stuDaoImplTest.testFindStudentById();
//            stuDaoImplTest.testFindStudentByName();
//            stuDaoImplTest.testInsertStudent();
//            stuDaoImplTest.testDeleteStudent();
            stuDaoImplTest.testUpdateStudent();
            stuDaoImplTest.testFindStudents();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
