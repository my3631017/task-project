package test;

import getsqlsession.GetSqlSession;
import mybatis.Student;
import org.apache.ibatis.session.SqlSession;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public class StudentTest {
    void selectOne(int id){//通过id查询
        try {
//            testStudent s=new testStudent();创建testStudent对象调用getSession方法，可不写
            //调用上面抽出来的getSession方法，获取sqlSession
            getsqlsession.GetSqlSession getSqlSession=new GetSqlSession();
            SqlSession sqlSession=getSqlSession.getSession();
            //通过SqlSession操作数据库
            //第一个参数：映射文件中statement的id，= namespace + statement的id
            //第二个参数：指定和映射文件中所匹配的parameterType类型的参数
            //selectOne表示查询出一条记录进行映射
            Student stu=sqlSession.selectOne("test.findStudentById",id);
            //输出获取的学生的信息
            System.out.println(stu);
            //释放资源
            sqlSession.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    void selectAll(){//查询所有学生
        try {
//            testStudent s=new testStudent();
            getsqlsession.GetSqlSession getSqlSession=new GetSqlSession();
            SqlSession sqlSession=getSqlSession.getSession();
//           用selectList表示查询出一条记录进行映射，映射存储在List集合中
            List<Student> students=sqlSession.selectList("test.findAllStudent");
//            创建迭代器好输出遍历结果
            Iterator<Student> stu=students.iterator();
            while (stu.hasNext()){
                System.out.println(stu.next());
            }
            sqlSession.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    void insert(int id, String name, String number){//新增学生
        try {
//            testStudent s=new testStudent();
            getsqlsession.GetSqlSession getSqlSession=new GetSqlSession();
            SqlSession sqlSession=getSqlSession.getSession();
            Long time=System.currentTimeMillis();
            //创建学生对象，包含id，name，number，create_at和update_at准备插入表格
            Student stu=new Student(id,name,number,time,time);
            sqlSession.insert("test.insertStudent", stu);
            sqlSession.commit();//提交事务
            sqlSession.close();//释放资源
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    void delete(int id){//删除学生
        try {
//            testStudent s=new testStudent();
            getsqlsession.GetSqlSession getSqlSession=new GetSqlSession();
            SqlSession sqlSession=getSqlSession.getSession();
            sqlSession.delete("test.deleteStudent",id);
            sqlSession.commit();
            sqlSession.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    void update(int id,String name,String number){//更新学生信息
        try {
//            testStudent s=new testStudent();
            getsqlsession.GetSqlSession getSqlSession=new GetSqlSession();
            SqlSession sqlSession=getSqlSession.getSession();
            Long time=System.currentTimeMillis();
            Student stu=new Student(id,name,number,time);
            sqlSession.update("test.updateStudent",stu);
            sqlSession.commit();
            sqlSession.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        StudentTest s=new StudentTest();
//        s.insert(3,"曹樾","74110");
//        s.delete(3);
        s.update(2,"李宗赢","234567");
//        s.selectOne(2);
        s.selectAll();
    }
}
